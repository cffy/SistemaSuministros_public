package Connector;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.util.Date;
import javax.swing.ImageIcon;
import java.sql.Blob;
import Aplicacion.Aplicacion;
import Entidades.Entidades_solicitud;
import Entidades.Entidades_usuario;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 * Class to handle all the Data Access Object (DAO).
 *
 * @author Freddy Cascante Fernandez
 * @version 08/08/2019/V1.0
 */

/*En una version mejorada, se eliminará el uso de variables globales
y se todas las transacciones con la BD será por procedimientos almacenados.
*/

public class DAO {

    private CallableStatement proc;
    String password = "";
    String usuario = "";
    String url = "";
    String urlAll = "";
    public static String DAOidSolicitante;
    public static String DAOidDespachador;
    public static String DAOnumParte = "";
    public static String DAOnota;
    public static String DAOdescripcion;
    public static String DAOunidadMedida;
    public static Date DAOfechaSolicitud;
    public static int DAOidSolicitud;
    public static int DAOqty;
    public static boolean DAOflagEntregado;
    public static boolean DAOflagRecibido;
    public static ImageIcon imgBD;
    Entidades_solicitud solicitudes = new Entidades_solicitud();

    /**
     * Method used to check if a part number introduced in JTextField exist in
     * DB
     *
     * @param numParte value introduced by user
     * @return returns the part number
     */
    public String verificarNumParte(String numParte) {
        String part = null;
        try {
            Connection co = null;
            Statement stm = null;
            ResultSet rs = null;
            String sql = "SELECT NumParte FROM dbo.Suministros_TablaRegistro WHERE NumParte = '" + numParte + "'";
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                part = rs.getString(1);
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return part;
    }

    /**
     * Method used to delete a supply
     *
     * @param numParte Part number to delete
     */
    public void eliminarSuministro(String numParte) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        try {
            co = Conexion.getConexion();
            PreparedStatement ps = co.prepareStatement("DELETE FROM dbo.Suministros_TablaRegistro WHERE NumParte =?");
            ps.setString(1, numParte);
            ps.executeUpdate();
//            ps.close();
//            co.close();
        } catch (Exception e) {
            System.out.println("Error: Clase DAO, método actualizarSuministro");
            e.printStackTrace();
        }
    }

    /**
     * Method used to update a supply
     *
     * @param numParte Part number to be updated
     * @param descripcion description to be updated
     * @param unidadMedida way to measure to be updated
     * @param bits image in bits format to be updated
     * @param len qty of bits
     * @throws java.sql.SQLException
     */
    public void actualizarSuministro(String numParte, String descripcion, String unidadMedida, FileInputStream bits, int len) throws SQLException {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        try {
            co = Conexion.getConexion();
            PreparedStatement ps = co.prepareStatement("UPDATE dbo.Suministros_TablaRegistro SET Descripcion = ?, UnidadMedida = ?, Imagen = ? WHERE NumParte ='" + numParte + "'");
            ps.setString(1, descripcion);
            ps.setString(2, unidadMedida);
            ps.setBinaryStream(3, bits, len);
            ps.executeUpdate();
//            ps.close();
//            co.close();
        } catch (Exception e) {
            System.out.println("Error: Clase DAO, método actualizarSuministro");
            e.printStackTrace();
        }
    }

    /**
     * Method used to check if a part number introduced in JTextField exist in
     * DB and returns all information related with this part number (only if
     * exist in DB) this method is used by RegistroNuevoSuministro
     *
     * @param numparte value introduced by user
     */
    public List<Entidades_solicitud> buscar(String numParte) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT NumParte, Descripcion, UnidadMedida, Imagen FROM dbo.Suministros_TableRegistro_TesImage WHERE NumParte = '" + numParte + "'";
        List<Entidades_solicitud> lista = new ArrayList<Entidades_solicitud>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            BufferedImage img = null;
            ImageIcon icono;
            while (rs.next()) {
                Entidades_solicitud solicitudes = new Entidades_solicitud();
                solicitudes.setNumParte(rs.getString(1));
                solicitudes.setDescripcion(rs.getString(2));
                solicitudes.setUnidadMedida(rs.getString(3));
                if (rs.getString(4) == null) {
                    solicitudes.setImagen(cargarNoImage());
                    lista.add(solicitudes);
                } else {
                    if (!rs.getString(1).equals("ImagenDefault") && !rs.getString(1).equals("NoImage")) {
                        Blob blob = rs.getBlob(4);
                        System.out.println("Blob: "+blob.toString().length());
                        if (blob != null) {
                            try {
                                byte[] data = blob.getBytes(1, (int) blob.length());
                                try {
                                    img = ImageIO.read(new ByteArrayInputStream(data));
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                                icono = new ImageIcon(img.getScaledInstance(260, 200, Image.SCALE_DEFAULT));
                                solicitudes.setImagen(icono);
                            } catch (SQLException e) {
                                JOptionPane.showMessageDialog(null, "No hay imagen");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay imagen");
                        }
                        lista.add(solicitudes);
                    }
                }
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;

    }

    /**
     * This method is used just by Control_materiales to make a request of an
     * specific part number
     */
    public void consultaNumParte(String numparte) {
        try {
            Connection co = null;
            Statement stm = null;
            ResultSet rs = null;
            String sql = "SELECT NumParte, Descripcion, UnidadMedida, Imagen FROM dbo.Suministros_TableRegistro_TesImage WHERE NumParte = '" + numparte + "'";
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                DAOnumParte = rs.getString(1);
                DAOdescripcion = rs.getString(2);
                DAOunidadMedida = rs.getString(3);
                Blob blob = rs.getBlob(4);
                System.out.println("Blob: "+blob.toString().length());
                if (rs.getBlob(4) == null) {
                    ImageIcon icono = cargarNoImage();

                    Aplicacion.vista_solicitudes.getLblImagen().setIcon(icono);
                } else ;
                if (blob != null) {
                    try {
                        byte[] data = blob.getBytes(1, (int) blob.length());
                        BufferedImage img = null;
                        try {
                            img = ImageIO.read(new ByteArrayInputStream(data));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                        ImageIcon icono = new ImageIcon(img);
                        Aplicacion.vista_solicitudes.getLblImagen().setIcon(new ImageIcon(img));
                    } catch (Exception e) {
                    }
                } else {

                }
            }
            if ("".equals(DAOnumParte)) {
                JOptionPane.showMessageDialog(null, "<html><h2>El número de parte no existe</html></h2>", "Información: Error", JOptionPane.ERROR_MESSAGE);
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method used to load a default image
     *
     * @param numParte value introduced by user
     * @return returns the part number
     */
    public ImageIcon cargarImagenDefault() {
        ImageIcon imageIcon = null;
        try {
            Connection co = null;
            Statement stm = null;
            ResultSet rs = null;
            String sql = "SELECT Imagen FROM dbo.Suministros_TablaRegistro WHERE NumParte = 'ImagenDefault'";
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                Blob blob = rs.getBlob(1);
                if (blob != null) {
                    try {
                        byte[] data = blob.getBytes(1, (int) blob.length());
                        BufferedImage img = null;
                        try {
                            img = ImageIO.read(new ByteArrayInputStream(data));
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                        imageIcon = new ImageIcon(img.getScaledInstance(260, 200, Image.SCALE_DEFAULT));
                        System.out.println("Imagen default loaded");
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "No hay imagen");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No hay imagen");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return imageIcon;
    }

    /**
     * Method used to load a default image if the supply has not one
     */
    public ImageIcon cargarNoImage() {
        ImageIcon imageIcon = null;
        try {
            Connection co = null;
            Statement stm = null;
            ResultSet rs = null;
            String sql = "SELECT Imagen FROM dbo.Suministros_TablaRegistro WHERE NumParte = 'NoImage'";
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                Blob blob = rs.getBlob(1);
                if (blob != null) {
                    try {
                        byte[] data = blob.getBytes(1, (int) blob.length());
                        BufferedImage img = null;
                        try {
                            img = ImageIO.read(new ByteArrayInputStream(data));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                        imageIcon = new ImageIcon(img.getScaledInstance(260, 200, Image.SCALE_DEFAULT));
                        System.out.println("no imagen loaded");
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "No hay imagen");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No hay imagen");
                }
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return imageIcon;
    }

    /**
     * Method used to introduce a new supply in DB
     *
     * @param numParte the specific part number ID
     * @param descripcion a description related with this part number
     * @param unidadMedida the way to calculate the qty per unity
     * @param bits image converted to bits to be saved in DB
     * @param len the total length of bits
     * @throws java.sql.SQLException
     */
    public void guardarNuevoSuministro(String numParte, String descripcion, String unidadMedida, FileInputStream bits, int len) throws SQLException {
        String mensaje = "";
        PreparedStatement stm = null;
        Connection con = null;
        String sql = "INSERT INTO dbo.Suministros_TableRegistro_TesImage VALUES (?,?,?,?,?)";
        try {
            con = Conexion.getConexion();
            stm = con.prepareStatement(sql);
            stm.setString(1, numParte);
            stm.setString(2, descripcion);
            stm.setString(3, unidadMedida);
            stm.setBinaryStream(4, bits, len);
            stm.setInt(5, 0);
            //stm.executeUpdate();
            System.out.println("Bits: \n"+bits.toString().length());
            System.out.println("Len: \n"+len);
        } catch (SQLException e) {
            mensaje = e.getMessage();
            if (mensaje.contains("Violation of 3PRIMARY KEY constraint")) {
                JOptionPane.showMessageDialog(null, "<html><h1>El número de parte ya existe</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "<html><h1>Número de parte registrado</html></h1>", "Información: Éxito!", JOptionPane.INFORMATION_MESSAGE);
            }
            System.out.println("Error> " + e.getMessage());
        }
//        con.close();
//        stm.close();
    }

    /**
     * Method used to register a new supply request (only if the PNumber exist
     * en DB)
     *
     * @param numParte part ID
     * @param cantidad qty need by user
     * @param usuario user who needs the supply
     * @param fecha date used by system to save the day of supply request
     * @throws java.text.ParseException
     */
    public void registrarSolicitud(String numParte, int cantidad, String usuario, Date fecha) throws ParseException {
        Date dateDP = new Date();
        Date dateSQL = new java.sql.Date(dateDP.getYear(), dateDP.getMonth(), dateDP.getDay());
        String sDate1 = Aplicacion.vista_solicitudes.getLblFecha().getText();
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(sDate1);
        Statement stm = null;
        Connection con = null;
        String numParteCorto = numParte;
        numParteCorto = numParteCorto.replaceAll(" ", "");
        String sql = "INSERT INTO dbo.Suministros_TableSolicitudes VALUES ('" + numParteCorto + "','" + cantidad + "','" + usuario + "','" + fecha + "'," + "'Solicitado'" + "," + "'Pendiente'" + "," + "'No asignado'" + ")";
        try {
            con = Conexion.getConexion();
            stm = con.createStatement();
            stm.execute(sql);
            System.out.println("dateParametro: " + fecha);
            System.out.println("Suministro registrado");
//            stm.close();
//            con.close();
        } catch (SQLException ex) {
            System.out.println("Error: método registrarSolicitud");
            ex.printStackTrace();
        }
    }

    /**
     * Method used to update the status of a supply request by Materials
     *
     * @param numParte part number to be updated
     * @param idSolicitud the specific request ID
     * @param status new status of request
     * @param nombreDespachador
     */
    public void entregarMateriales(String numParte, int idSolicitud, String status, String nombreDespachador) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        try {
            co = Conexion.getConexion();
            PreparedStatement ps = co.prepareStatement("UPDATE dbo.Suministros_TableSolicitudes SET EstatusMateriales = ?, Nombredespachador = ? WHERE NumParte ='" + numParte + "' AND IdSolicitud = '" + idSolicitud + "'");
            ps.setString(1, status);
            ps.setString(2, nombreDespachador);
            ps.executeUpdate();
//            ps.close();
//            co.close();
        } catch (Exception e) {
            System.out.println("Error: Clase DAO, método entregarSolicitud");
            e.printStackTrace();
        }
    }

    /**
     * Method used to update a user request status
     *
     * @param numParte part number to be updated
     * @param idSolicitud the specific Id of a request
     * @param status the new status of the request
     */
    public void actiualizarSolicitud(String numParte, int idSolicitud, String status) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        try {
            co = Conexion.getConexion();
            PreparedStatement ps = co.prepareStatement("UPDATE dbo.Suministros_TableSolicitudes SET Estatus = ? WHERE NumParte ='" + numParte + "' AND IdSolicitud = '" + idSolicitud + "'");
            ps.setString(1, status);
            ps.executeUpdate();
//            ps.close();
//            co.close();
        } catch (Exception e) {
            System.out.println("Error: Clase DAO, método entregarSolicitud");
            e.printStackTrace();
        }
    }

    /**
     * Method used to load the catalog with all supplies
     */
    public List<Entidades_solicitud> cargarCatalogo() {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT NumParte, Descripcion, UnidadMedida, Imagen FROM dbo.Suministros_TablaRegistro";
        List<Entidades_solicitud> catalogo = new ArrayList<Entidades_solicitud>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            BufferedImage img = null;
            ImageIcon icono;
            while (rs.next()) {
                Entidades_solicitud solicitudes = new Entidades_solicitud();
                solicitudes.setNumParte(rs.getString(1));
                solicitudes.setDescripcion(rs.getString(2));
                solicitudes.setUnidadMedida(rs.getString(3));
                if (rs.getString(4) == null) {
                    solicitudes.setImagen(cargarNoImage());
                    catalogo.add(solicitudes);
                } else {
                    if (!rs.getString(1).equals("ImagenDefault") && !rs.getString(1).equals("NoImage")) {
                        Blob blob = rs.getBlob(4);
                        if (blob != null) {
                            try {
                                byte[] data = blob.getBytes(1, (int) blob.length());
                                try {
                                    img = ImageIO.read(new ByteArrayInputStream(data));
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                                icono = new ImageIcon(img.getScaledInstance(260, 200, Image.SCALE_DEFAULT));
                                solicitudes.setImagen(icono);
                            } catch (SQLException e) {
                                JOptionPane.showMessageDialog(null, "No hay imagen");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay imagen");
                        }
                        catalogo.add(solicitudes);
                    }
                }
                
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return catalogo;
    }

    /**
     * Method used to get all users request
     */
    public List<Entidades_solicitud> obtenerSolicitudes() {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM dbo.Suministros_TableSolicitudes ORDER BY IdSolicitud desc";
        List<Entidades_solicitud> solicitud = new ArrayList<Entidades_solicitud>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                solicitudes = new Entidades_solicitud();
                solicitudes.setNumParte(rs.getString(1));
                solicitudes.setQty(rs.getInt(2));
                solicitudes.setUser(rs.getString(3));
                solicitudes.setFechaSolicitud(rs.getDate(4)); //(java.sql.Date)
                solicitudes.setEstadoSolicitud(rs.getString(5));
                solicitudes.setEstadoMateriales(rs.getString(6));
                solicitudes.setNombreDespachador(rs.getString(7));
                solicitudes.setIdSolicitud(rs.getInt(8));
                solicitud.add(solicitudes);
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            System.out.println("Error: Clase DAO, método ObtenerPorID");
            e.printStackTrace();
        }
        return solicitud;
    }
    
    public List<Entidades_solicitud> obtenerSolicitudes100() {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT TOP 100 * FROM dbo.Suministros_TableSolicitudes ORDER BY IdSolicitud desc";
        List<Entidades_solicitud> solicitud = new ArrayList<Entidades_solicitud>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                solicitudes = new Entidades_solicitud();
                solicitudes.setNumParte(rs.getString(1));
                solicitudes.setQty(rs.getInt(2));
                solicitudes.setUser(rs.getString(3));
                solicitudes.setFechaSolicitud(rs.getDate(4)); //(java.sql.Date)
                solicitudes.setEstadoSolicitud(rs.getString(5));
                solicitudes.setEstadoMateriales(rs.getString(6));
                solicitudes.setNombreDespachador(rs.getString(7));
                solicitudes.setIdSolicitud(rs.getInt(8));
                solicitud.add(solicitudes);
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            System.out.println("Error: Clase DAO, método ObtenerPorID");
            e.printStackTrace();
        }
        return solicitud;
    }

    /**
     * Method used to validate a system user
     *
     * @param username the specific username per user
     * @param password the specific password per user
     * @return returns a user only if exist in DB
     */
    public List<Entidades_usuario> login(String username, String password) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT Nombreempleado, ApellidoEmpleado, Password FROM dbo.TableEmpleados WHERE IdEmpleado = '" + username + "' AND Password = '" + password + "'";
        List<Entidades_usuario> solicitudLogin = new ArrayList<Entidades_usuario>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            if (rs.next()) {
                Entidades_usuario log = new Entidades_usuario();
                log.setNombre(rs.getString(1));
                log.setApellidos(rs.getString(2));
                if (!rs.getString(3).equals("")) {
                    solicitudLogin.add(log);
                }

            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            System.out.println("Error: Clase DAO, método login");
            e.printStackTrace();
        }
        return solicitudLogin;
    }

    /**
     * Method used to load the request by user
     *
     * @param user to get all request under this username
     * @return returns a list of request by user
     */
    public List<Entidades_solicitud> obtenerSolicitudesXusuario(String user) {
        Connection co = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM dbo.Suministros_TableSolicitudes WHERE Usuario = '" + user + "' ORDER BY IdSolicitud desc";
        List<Entidades_solicitud> solicitud = new ArrayList<Entidades_solicitud>();
        try {
            co = Conexion.getConexion();
            stm = co.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                Entidades_solicitud solicitudes = new Entidades_solicitud();
                solicitudes.setNumParte(rs.getString(1));
                solicitudes.setQty(rs.getInt(2));
                solicitudes.setUser(rs.getString(3));
                solicitudes.setFechaSolicitud((java.util.Date) rs.getDate(4));
                solicitudes.setEstadoSolicitud(rs.getString(5));
                solicitudes.setEstadoMateriales(rs.getString(6));
                solicitudes.setNombreDespachador(rs.getString(7));
                solicitudes.setIdSolicitud(rs.getInt(8));
                solicitud.add(solicitudes);
            }
//            stm.close();
//            rs.close();
//            co.close();
        } catch (SQLException e) {
            System.out.println("Error: Clase DAO, método ObtenerPorID");
            e.printStackTrace();
        }
        return solicitud;
    }

    /**
     * Method user to create a temporal Entidades_solicitud
     */
    private Entidades_solicitud solicitud(ResultSet rs) throws Exception {
        Entidades_solicitud temporal = new Entidades_solicitud();
        temporal.setNumParte(rs.getString("NumParte"));
        temporal.setQty(rs.getInt("Cantidad"));
        temporal.setUser(rs.getString("Usuario"));
        temporal.setFechaSolicitud(rs.getDate("Fecha"));
        temporal.setEstadoSolicitud(rs.getString("Estatus"));
        temporal.setEstadoMateriales(rs.getString("EstatusMateriales"));
        temporal.setIdSolicitud(rs.getInt("IdSolicitud"));
        return temporal;
    }

}
