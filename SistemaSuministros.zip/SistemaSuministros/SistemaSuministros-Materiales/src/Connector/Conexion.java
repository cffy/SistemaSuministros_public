package Connector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Class to establish a connection with DB
 * @author Freddy Cascante Fernández
 * @version 09/08/2019/V1.0
 */
public class Conexion {

    /**
     * Method used to establish a connection with DB
     * @return returns a connection 
     * 
     */
    
    
    private static Connection conexion;

    public static Connection getConexion() {
        if (conexion == null) {
            
            String urlAll = "jdbc:sqlserver://server-name;database=database-name;user=user;password=password";
            try {
                conexion = DriverManager.getConnection(urlAll);
                if (conexion != null) {
                    System.out.println("Conectado " + conexion.toString());
                } 
            } catch (SQLException e) {
                System.out.println("No se pudo conectar a la base de datos");
                e.printStackTrace();
                System.out.println("\n "+e.getMessage());
            }
            return conexion;
        } else {
            System.out.println("Coneccion en uso " + conexion.toString());
        }
        return conexion;
    }
}
