package Modelo;

import Entidades.Entidades_solicitud;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * Class to generate a JTableModel
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Modelo_table_materiales extends AbstractTableModel {

    public static final int NumParte = 0,
            Cantidad = 1,
            Usuario = 2,
            Fecha = 3,
            Estatus = 4,
            EstatusMateriales = 5,
            NombreDespachador = 6,
            IdSolicitud = 7;

    private String[] nombresColumnas = new String[8];

    private List<Entidades_solicitud> filas;
    int[] columnas;

    /**
     * Constructor de la clase, recibe por parametro los datos de las filas y
     * las columnas del modelo de la tabla.
     *
     * @param fila
     * @param columna
     */
    public Modelo_table_materiales(List<Entidades_solicitud> fila, int[] columna) {
        this.filas = fila;
        this.columnas = columna;
        this.iniciarNombresColumnas();
    }

    /**
     * Método para setear la información de las filas de la tabla
     *
     * @param filas
     */
    public void setFilas(List<Entidades_solicitud> filas) {
        this.filas = filas;
    }

    /**
     * Método para obtener información para las filas de la tabla
     *
     * @return retorna la informacion de un paciente.
     */
    public List<Entidades_solicitud> getFilas() {
        return this.filas;
    }

    /**
     * Método para iniciar el nombre de las columnas de la tabla.
     */
    //CADA COLUMNA CON SU RESPECTIVO NOMBRE
    private void iniciarNombresColumnas() {

        nombresColumnas[NumParte] = "<html><h3>Número de parte</html></h3>";
        nombresColumnas[Cantidad] = "<html><h3>Cantidad</html></h3>";
        nombresColumnas[Usuario] = "<html><h3>Solicitante</html></h3>";
        nombresColumnas[Fecha] = "<html><h3>Fecha</html></h3>";
        nombresColumnas[Estatus] = "<html><h3>Estatus solicitud</html></h3>";
        nombresColumnas[EstatusMateriales] = "<html><h3>Estatus materiales</html></h3>";
        nombresColumnas[NombreDespachador] = "<html><h3>Despachador</html></h3>";
        nombresColumnas[IdSolicitud] = "<html><h3>IdSolicitud</html></h3>";

    }

    /**
     * Método para obtener el total de filas de la tabla.
     *
     * @return retorna el total de filas.
     */
    public int getRowCount() {
        return this.filas.size();
    }

    /**
     * Método para obtener el total de columnas de la tabla.
     *
     * @return retorna el total de columnas.
     */
    public int getColumnCount() {
        return this.columnas.length;
    }

    /**
     * Método para obtener el nombre de las columnas de la tabla.
     *
     * @return retorna el nombre de las columnas.
     */
    public String getColumnName(int columna) {
        return nombresColumnas[columnas[columna]];
    }

    /**
     * Método para obtener los datos de las filas y columnas de la tabla.
     *
     * @return retorna los datos de las filas y columnas de la tabla.
     */
    @Override
    public Object getValueAt(int fila, int columna) {
        Entidades_solicitud entidades_solicitud = filas.get(fila);
        switch (columnas[columna]) {
            case NumParte:
                return entidades_solicitud.getNumParte();
            case Cantidad:
                return entidades_solicitud.getQty();
            case Usuario:
                return entidades_solicitud.getUser();
            case Fecha:
                return entidades_solicitud.getFechaSolicitud();
            case Estatus:
                return entidades_solicitud.getEstadoSolicitud();
            case EstatusMateriales:
                return entidades_solicitud.getEstadoMateriales();
            case NombreDespachador:
                return entidades_solicitud.getNombreDespachador();
            case IdSolicitud:
                return entidades_solicitud.getIdSolicitud();
            default:
                return "ERROR";
        }
    }

    /**
     * Método para obtener el dato de una fila de la tabla.
     *
     * @param fila
     * @return retorna el dato de una fila de la tabla.
     */
    public Entidades_solicitud getRowAt(int fila) {
        return filas.get(fila);
    }

    /**
     * Método para obtener ColumnClass con base en el Index
     *
     * @param fila
     * @return retorna un objeto.Class
     */
    public Class<?> getColumnClass(int columnIndex) {
        if (filas.isEmpty()) {
            return Object.class;
        }
        return getValueAt(0, columnIndex).getClass();
    }
}
