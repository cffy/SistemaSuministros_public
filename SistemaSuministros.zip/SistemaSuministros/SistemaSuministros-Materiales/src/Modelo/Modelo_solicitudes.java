/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Entidades.Entidades_solicitud;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import Aplicacion.Aplicacion;
import java.util.List;

/**
 * Class to Model to Vista_solicitudes and Control_solicitudes
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Modelo_solicitudes extends Observable {

    public Modelo_table_solicitudes modeloTableSolicitudes;
    public ArrayList<Entidades.Entidades_solicitud> solicitudes = new ArrayList<Entidades_solicitud>();

    /**
     * Constructor of class
     */
    public Modelo_solicitudes() {
        this.modeloTableSolicitudes = Aplicacion.modelo_table_solicitudes;
        notificarCambios();
    }

    /**
     * method used to add a new request to a JList
     */
    public void agregarSolicitud(String numParte, int cantidad) {
        Entidades_solicitud solicitud = new Entidades_solicitud();
        solicitud.setNumParte(numParte);
        solicitud.setQty(cantidad);
        solicitudes.add(solicitud);
        setTable(solicitudes);
    }

    public static int[] columnasTabla = {
        Modelo.Modelo_table_catalogo.NumParte,
        Modelo.Modelo_table_catalogo.Descripcion};

    /**
     * Method used to set data in Vista_table_solicitudes.
     */
    public void setTable(List<Entidades.Entidades_solicitud> listaDeSolicitudes) {
        this.modeloTableSolicitudes.setFilas(listaDeSolicitudes);
        notificarCambios();
    }

    /**
     * Method to add a observer to Vista_solicitudes
     */
    @Override
    public void addObserver(Observer o) {
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }

    /**
     * Method used to get a Date
     */
    public String fecha() {
        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(fecha);
    }

    /**
     * method used to notify changes in view
     */
    public void notificarCambios() {
        setChanged();
        notifyObservers();
        modeloTableSolicitudes.fireTableDataChanged();
    }
}
