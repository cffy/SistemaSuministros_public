/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Aplicacion.Aplicacion;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.DefaultListModel;

/**
 * Class Model to Vista_catalogo and Control_catalogo
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Modelo_catalogo extends Observable {

    private Modelo_table_catalogo modelo_table;
    public static ArrayList<String> pedidos;
    DefaultListModel listModel;

    public static int[] columnasTabla = {
        Modelo.Modelo_table_catalogo.NumParte,
        Modelo.Modelo_table_catalogo.Descripcion,
        Modelo.Modelo_table_catalogo.UnidadMedida,
        Modelo.Modelo_table_catalogo.Imagen};

    /**
     * Constructor of class
     */
    public Modelo_catalogo() {
        this.listModel = new DefaultListModel();
        this.modelo_table = Aplicacion.modelo_table_catalogo;
        notificarCambios();
    }

    /**
     * Method used to set data in Vista_table_catalogo.
     */
    public void setTable(List<Entidades.Entidades_solicitud> listaDeSolicitudes) {
        this.modelo_table.setFilas(listaDeSolicitudes);
        notificarCambios();
    }

    /**
     * Method used to obtain the TableModel of Class Modelo_table_catalogo
     */
    public Modelo_table_catalogo getTableModel() {
        return this.modelo_table;
    }

    /**
     * Method used to load a JTableModel.
     */
    public void setTableModel(Modelo_table_catalogo modelo_table_catalogo) {
        this.modelo_table = modelo_table_catalogo;
    }

    /**
     * Method to add a observer to Vista_catalogo
     */
    @Override
    public void addObserver(Observer o) {
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }

    /**
     * method used to notify changes in view
     */
    public void notificarCambios() {
        setChanged();
        notifyObservers();
        modelo_table.fireTableDataChanged();
    }

    public static ArrayList<String> getPedidos() {
        return pedidos;
    }

    public DefaultListModel getListModel() {
        return listModel;
    }
}
