/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Entidades.Entidades_solicitud;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * Class to generate a JTableModel
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Modelo_table_catalogo extends AbstractTableModel {

    public static final int NumParte = 0,
            Descripcion = 1,
            UnidadMedida = 2,
            Imagen = 3;

    private String[] nombresColumnas = new String[4];

    private List<Entidades_solicitud> filas;
    int[] columnas;

    /**
     * Constructor de la clase, recibe por parametro los datos de las filas y
     * las columnas del modelo de la tabla.
     *
     * @param fila
     * @param columna
     */
    public Modelo_table_catalogo(List<Entidades_solicitud> fila, int[] columna) {
        this.filas = fila;
        this.columnas = columna;
        this.iniciarNombresColumnas();
    }

    /**
     * Método para setear la información de las filas de la tabla
     *
     * @param filas
     */
    public void setFilas(List<Entidades_solicitud> filas) {
        this.filas = filas;
    }

    /**
     * Método para obtener información para las filas de la tabla
     *
     * @return retorna la informacion de un paciente.
     */
    public List<Entidades_solicitud> getFilas() {
        return this.filas;
    }

    /**
     * Método para iniciar el nombre de las columnas de la tabla.
     */
    //CADA COLUMNA CON SU RESPECTIVO NOMBRE
    private void iniciarNombresColumnas() {

        nombresColumnas[NumParte] = "<html><h2>Número de parte</html></h2>";
        nombresColumnas[Descripcion] = "<html><h2>Descripción</html></h2>";
        nombresColumnas[UnidadMedida] = "<html><h2>Unidad de medida</html></h2>";
        nombresColumnas[Imagen] = "<html><h2>Imagen</html></h2>";
    }

    /**
     * Método para obtener el total de filas de la tabla.
     *
     * @return retorna el total de filas.
     */
    public int getRowCount() {
        return this.filas.size();
    }

    /**
     * Método para obtener el total de columnas de la tabla.
     *
     * @return retorna el total de columnas.
     */
    public int getColumnCount() {
        return this.columnas.length;
    }

    /**
     * Método para obtener el nombre de las columnas de la tabla.
     *
     * @return retorna el nombre de las columnas.
     */
    public String getColumnName(int columna) {
        return nombresColumnas[columnas[columna]];
    }

    /**
     * Método para obtener los datos de las filas y columnas de la tabla.
     *
     * @return retorna los datos de las filas y columnas de la tabla.
     */
    @Override
    public Object getValueAt(int fila, int columna) {
        Entidades_solicitud entidades_solicitud = filas.get(fila);
        switch (columnas[columna]) {
            case NumParte:
                return entidades_solicitud.getNumParte();
            case Descripcion:
                return entidades_solicitud.getDescripcion();
            case UnidadMedida:
                return entidades_solicitud.getUnidadMedida();
            case Imagen:
                return entidades_solicitud.getImagen();
            default:
                return "ERROR";
        }
    }

    /**
     * Método para obtener el dato de una fila de la tabla.
     *
     * @param fila
     * @return retorna el dato de una fila de la tabla.
     */
    public Entidades_solicitud getRowAt(int fila) {
        return filas.get(fila);
    }

    /**
     * Método para obtener ColumnClass con base en el Index
     *
     * @param fila
     * @return retorna un objeto.Class
     */
    public Class<?> getColumnClass(int columnIndex) {
        if (filas.isEmpty()) {
            return Object.class;
        }
        return getValueAt(0, columnIndex).getClass();
    }
}
