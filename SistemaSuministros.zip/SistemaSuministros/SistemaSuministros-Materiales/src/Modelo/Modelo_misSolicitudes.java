/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.DefaultListModel;

/**
 * Class model to Vista_misSolicitudes and Control_misSolicitudes
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Modelo_misSolicitudes extends Observable {

    private Modelo_table_materiales modelo_table;
    public static ArrayList<String> pedidos;
    DefaultListModel listModel;

    public static int[] columnasTabla = {
        Modelo.Modelo_table_materiales.NumParte,
        Modelo.Modelo_table_materiales.Cantidad,
        Modelo.Modelo_table_materiales.Usuario,
        Modelo.Modelo_table_materiales.Fecha,
        Modelo.Modelo_table_materiales.Estatus,
        Modelo.Modelo_table_materiales.EstatusMateriales,
        Modelo.Modelo_table_materiales.NombreDespachador,
        Modelo.Modelo_table_materiales.IdSolicitud};

    /**
     * Constructor of class
     */
    public Modelo_misSolicitudes() {
        this.listModel = new DefaultListModel();
        this.modelo_table = Aplicacion.Aplicacion.modelo_table_materiales;
        notificarCambios();
    }

    /**
     * Method used to set data in Vista_table_catalogo.
     */
    public void setTable(List<Entidades.Entidades_solicitud> listaDeSolicitudes) {
        this.modelo_table.setFilas(listaDeSolicitudes);
        notificarCambios();
    }

    /**
     * Method used to obtain the TableModel of Class Modelo_table_catalogo
     */
    public Modelo_table_materiales getTableModel() {
        return this.modelo_table;
    }

    /**
     * Method used to load a JTableModel.
     */
    public void setTableModel(Modelo_table_materiales modelo_table_materiales) {
        this.modelo_table = modelo_table_materiales;
    }

    /**
     * Method to add a observer to Vista_misSolicitudes
     */
    @Override
    public void addObserver(Observer o) {
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }

    /**
     * Method used to return a Date
     */
    public String fecha() {
        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(fecha);
    }

    public void setListModel(DefaultListModel listModel) {
        this.listModel = listModel;
    }

    /**
     * method used to notify changes in view
     */
    public void notificarCambios() {
        setChanged();
        notifyObservers();
        modelo_table.fireTableDataChanged();
    }

    public static ArrayList<String> getPedidos() {
        return pedidos;
    }

    public DefaultListModel getListModel() {
        return listModel;
    }

}
