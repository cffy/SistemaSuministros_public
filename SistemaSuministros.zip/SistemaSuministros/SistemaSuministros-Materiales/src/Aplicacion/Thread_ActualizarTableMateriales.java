package Aplicacion;

import static Aplicacion.Aplicacion.control_materiales;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class thread to keep updated the JTable in Vista_materiales.
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Thread_ActualizarTableMateriales implements Runnable {

    /**
     * Method to update JTbale of Vista_materiales
     */
    @Override
    public void run() {
        for (;;) {
            control_materiales.cargarTablaMateriales100();
            try {
                Thread.sleep(30000); //30 segundos
                System.out.println("Tabla materiales actualizada");
            } catch (InterruptedException ex) {
                Logger.getLogger(Aplicacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
