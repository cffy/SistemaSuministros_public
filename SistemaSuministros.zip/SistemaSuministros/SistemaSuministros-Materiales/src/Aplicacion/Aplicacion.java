package Aplicacion;

import Connector.Conexion;
import Control.Control_solicitudes;
import Entidades.Entidades_solicitud;
import Modelo.Modelo_solicitudes;
import Vista.Vista_solicitudes;
import java.time.LocalDate;
import Connector.DAO;
import Control.Control_catalogo;
import Control.Control_login;
import Control.Control_materiales;
import Control.Control_misSolicitudes;
import Control.Control_registroSuministro;
import Modelo.Modelo_catalogo;
import Modelo.Modelo_materiales;
import Modelo.Modelo_misSolicitudes;
import Modelo.Modelo_registroSuministro;
import Modelo.Modelo_table_catalogo;
import Modelo.Modelo_table_materiales;
import Modelo.Modelo_table_solicitudes;
import Vista.Vista_catalogo;
import Vista.Vista_materiales;
import Vista.Vista_misSolicitudes;
import Vista.Vista_registroSuministro;
import java.util.ArrayList;
import Modelo.Modelo_login;
import Vista.Vista_loading;
import Vista.Vista_login;
import java.sql.Connection;
import javax.swing.JOptionPane;

/**
 * Clase para ejecutar las funciones de arranque de la aplicación, inicializar
 * los controles, vistas, DAO, TableModels, modelos e hilos de ejecucion.
 *
 * @author Freddy Cascante Fernandez
 * @version 08/08/2019/V1.0
 */
public class Aplicacion {

    //modelos
    public static Modelo_solicitudes modelo_solicitudes;
    public static Modelo_materiales modelo_materiales;
    public static Modelo_misSolicitudes modelo_misSolicitudes;
    public static Modelo_catalogo modelo_catalogo;
    public static Modelo_registroSuministro modelo_registroSuministro;
    public static Modelo_login modelo_login;

    //vistas
    public static Vista_solicitudes vista_solicitudes = new Vista_solicitudes();
    public static Vista_materiales vista_materiales = new Vista_materiales();
    public static Vista_misSolicitudes vista_misSolicitudes = new Vista_misSolicitudes();
    public static Vista_catalogo vista_catalogo = new Vista_catalogo();
    public static Vista_registroSuministro vista_registroSuministro = new Vista_registroSuministro();
    public static Vista_login vista_login = new Vista_login();

    //controles
    public static Control_solicitudes control_solicitudes;
    public static Control_materiales control_materiales;
    public static Control_misSolicitudes control_misSolicitudes;
    public static Control_catalogo control_catalogo;
    public static Control_registroSuministro control_registroSuministro;
    public static Control_login control_login;

    //entidades
    public static Entidades_solicitud entidades_solicitud;

    //dao
    public static DAO dao;

    //tableModels
    public static Modelo_table_materiales modelo_table_materiales = new Modelo_table_materiales(new ArrayList<Entidades_solicitud>(), Modelo_materiales.columnasTabla);
    public static Modelo_table_catalogo modelo_table_catalogo = new Modelo_table_catalogo(new ArrayList<Entidades_solicitud>(), Modelo_catalogo.columnasTabla);
    public static Modelo_table_solicitudes modelo_table_solicitudes = new Modelo_table_solicitudes(new ArrayList<Entidades_solicitud>(), Modelo_solicitudes.columnasTabla);

    /**
     * Método para crear una instancia de Vista_solicitudes
     */
    public static void crearVistaSolicitudes() {
        modelo_solicitudes = new Modelo_solicitudes();
        vista_solicitudes = new Vista_solicitudes();
        control_solicitudes = new Control_solicitudes(modelo_solicitudes, vista_solicitudes, entidades_solicitud, modelo_table_solicitudes);
        vista_solicitudes.setVisible(true);
    }

    /**
     * Método para crear una instancia de Vista_materiales
     */
    public static void crearVistaMateriales() {
        modelo_materiales = new Modelo_materiales();
        vista_materiales = new Vista_materiales();
        control_materiales = new Control_materiales(modelo_materiales, vista_materiales, entidades_solicitud, modelo_table_materiales);
        control_materiales.cargarTablaMateriales();
        vista_materiales.setVisible(true);
        Thread_ActualizarTableMateriales th_actualizar = new Thread_ActualizarTableMateriales();
        new Thread(th_actualizar).start();
    }

    /**
     * Método para crear una instancia de Vista_misSolicitudes
     */
    public static void crearVistaMisSolicitudes() {
        modelo_misSolicitudes = new Modelo_misSolicitudes();
        vista_misSolicitudes = new Vista_misSolicitudes();
        control_misSolicitudes = new Control_misSolicitudes(modelo_misSolicitudes, vista_misSolicitudes, modelo_table_materiales);
        control_misSolicitudes.cargarTablaMisSolicitudes();
        vista_misSolicitudes.setVisible(true);
    }

    /**
     * Método para crear una instancia de Vista_catalogo
     */
    public static void crearVistaCatalogo() {
//        modelo_catalogo = new Modelo_catalogo();
//        Vista_catalogo vista_catalogo = new Vista_catalogo();
//        control_catalogo = new Control_catalogo(modelo_catalogo, vista_catalogo, modelo_table_catalogo);
//        vista_catalogo.setVisible(true);
        if (control_catalogo != null) {
            System.out.println("");
        }
    }

    public static void getCrearVistaCatalogo() {
        Control_catalogo.getCatalogo();
    }

    /**
     * Método para crear una instancia de Vista_registroSuministro
     */
    public static void crearVistaRegistroSuministro() {
        modelo_registroSuministro = new Modelo_registroSuministro();
        vista_registroSuministro = new Vista_registroSuministro();
        control_registroSuministro = new Control_registroSuministro(modelo_registroSuministro, vista_registroSuministro);
        vista_registroSuministro.setVisible(true);
    }

    /**
     * Método para crear una instancia de Vista_login
     */
    public static void crearVistalogin() {
        modelo_login = new Modelo_login();
        vista_login = new Vista_login();
        control_login = new Control_login(modelo_login, vista_login);
        vista_login.setVisible(true);
    }

    /**
     * Method used to create a loading view meanwhile database connection is
     * verified
     */
    public static void VerLoading() {
        Vista_loading loading = new Vista_loading();
        loading.setVisible(true);
    }

    /**
     * Método para validad la connexión con la base de datos
     */
    public static boolean testConexion() {
        boolean flag = false;
        Vista_loading l = new Vista_loading();
        l.setVisible(true);
        Connection co = null;
        try {
            co = Conexion.getConexion();
            if (co != null) {
                flag = true;
            } else {
                JOptionPane.showMessageDialog(null, "<html><h1>No existe conexión con la base de datos</html></h1>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                flag = false;
                System.exit(0);
            }
            l.setVisible(false);
        } catch (Exception e) {
            System.out.println("No DataBase conection");
        }
        return flag;
    }

    /**
     * Método para obtener una fecha
     */
    public static LocalDate fechaLocal() {
        LocalDate date = LocalDate.now();
        return date;
    }

    /**
     * Ejecuta las funciones de arranque del sistema
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Aplicacion.dao = new DAO();
        //crearVistaSolicitudes();
        //crearVistaMisSolicitudes();
        //crearVistaRegistroSuministro();
        //crearVistaCatalogo();

        //if (testConexion() == true) crearVistalogin();
        if (testConexion() == true) crearVistaMateriales();
        //crearVistaMateriales();
        //Ultimo cambio, cancelar solicitudes, indicar cuando un suministro no esta disponible.
    }
}



/*Last change addded by me*/