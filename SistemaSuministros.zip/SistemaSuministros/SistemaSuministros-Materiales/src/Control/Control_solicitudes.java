/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Aplicacion.Aplicacion;
import static Aplicacion.Aplicacion.vista_solicitudes;
import Connector.DAO;
import Entidades.Entidades_solicitud;
import Modelo.Modelo_catalogo;
import Modelo.Modelo_solicitudes;
import Modelo.Modelo_table_solicitudes;
import Vista.Vista_solicitudes;
import static java.awt.Frame.ICONIFIED;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

/**
 * Class control to Modelo_solicitudes and Vista_solicitudes
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_solicitudes implements MouseListener {

    Modelo_solicitudes model = new Modelo_solicitudes();
    Modelo_catalogo modelo_catalogo;
    Vista_solicitudes visSolicitudes;
    Entidades_solicitud entiSolicitudes;
    DAO dao;
    Modelo_table_solicitudes modelo_table_solicitudes;
    Point point = new Point();
    int selectedRow;
    int selectedColumns;

    /**
     * Constructor of class
     *
     * @param model instance of Modelo_solicitudes
     * @param visSolicitudes instance of Vista_solicitudes
     * @param entiSolicitudes instance of Entidades_solicitudes
     * @param modelo_table_solicitudes instance of Modelo_table_solicitudes
     */
    public Control_solicitudes(Modelo_solicitudes model, Vista_solicitudes visSolicitudes, Entidades_solicitud entiSolicitudes, Modelo_table_solicitudes modelo_table_solicitudes) {
        this.model = new Modelo_solicitudes();
        this.modelo_catalogo = new Modelo_catalogo();
        this.entiSolicitudes = new Entidades_solicitud();
        this.visSolicitudes = visSolicitudes;
        this.visSolicitudes.setControl(this);
        this.visSolicitudes.setModelo(model);
        this.visSolicitudes.getLblFecha().setText(model.fecha());
        this.visSolicitudes.getTableSuministros().setModel(modelo_table_solicitudes);
        this.dao = new DAO();
    }

    /**
     * Method used to make a new request
     */
    public void hacerSolicitud() {
        String np = "";
        int qty = 0;

        if (vista_solicitudes.getTableSuministros().getRowCount() > 0) {
            try {
                for (int i = 0; i < vista_solicitudes.getTableSuministros().getRowCount(); i++) {
                    np = model.solicitudes.get(i).getNumParte();
                    qty = model.solicitudes.get(i).getQty();
                    Aplicacion.dao.registrarSolicitud(np, qty, vista_solicitudes.getLblUser().getText(), Date.valueOf(vista_solicitudes.getLblFecha().getText()));
                }
                JOptionPane.showMessageDialog(null, "<html><h1>Suministro(s) solicitado(s)</html></h1>", "Información: Éxito!", JOptionPane.INFORMATION_MESSAGE);
                limpiar();
                DAO.DAOdescripcion = "";
                DAO.DAOnumParte = "";
                DAO.DAOunidadMedida = "";
            } catch (ParseException ex) {
                Logger.getLogger(Control_solicitudes.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "<html><h2>La lista está vacía</html></h2>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        switch (e.getComponent().getName()) {

            case "btnCerrar": {
                System.exit(0);
                break;
            }

            case "btnMinimizar": {
                visSolicitudes.setExtendedState(ICONIFIED);
                break;
            }

            case "btnBuscarNparte": {
                vista_solicitudes.getTxtCantidad().setEditable(true);
                vista_solicitudes.getTxtCantidad().setText("");
                if (vista_solicitudes.getTxtNumParte().getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "<html><h2>El número de parte no existe</html></h2>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                    vista_solicitudes.getTxtNumParte().setText("");
                    limpiar();
                    model.notificarCambios();
                } else {
                    try {
                        Aplicacion.dao.consultaNumParte(vista_solicitudes.getTxtNumParte().getText());
                        visSolicitudes.getLblNumeroParte().setText(DAO.DAOnumParte);
                        visSolicitudes.getLblDescripcion().setText(DAO.DAOdescripcion);
                        visSolicitudes.getLblUnidadMedida().setText(DAO.DAOunidadMedida);
                        if (vista_solicitudes.getTxtNumParte().getText().equals("990.1050") || vista_solicitudes.getTxtNumParte().getText().equals("990.SN100C") || vista_solicitudes.getTxtNumParte().getText().equals("890.1084") || vista_solicitudes.getTxtNumParte().getText().equals("991.1024")) {
                            vista_solicitudes.getTxtCantidad().setEditable(false);
                            JOptionPane.showMessageDialog(null, "<html><h2>Para agregar una cantidad de clic en boton AGREGAR</html></h2>", "Información: Error", JOptionPane.INFORMATION_MESSAGE);
                        }
                    } catch (Exception ex) {
                        System.out.println("Error> " + ex.getMessage());
                    }
                    model.notificarCambios();
                    DAO.DAOnumParte = "";
                    DAO.DAOdescripcion = "";
                    DAO.DAOunidadMedida = "";

                }
                break;
            }

            case "btnAgregarLista": {
                try {

                    //
                    if (vista_solicitudes.getTxtNumParte().getText().equals("990.1050") || vista_solicitudes.getTxtNumParte().getText().equals("990.SN100C") || vista_solicitudes.getTxtNumParte().getText().equals("890.1084") || vista_solicitudes.getTxtNumParte().getText().equals("991.1024")) {
                        String paramNumParte = vista_solicitudes.getTxtNumParte().getText();
                        switch (paramNumParte) {
                            case "990.1050": {
                                SpinnerNumberModel sModel = new SpinnerNumberModel(25, 25, 1000000, 25);//(0, 0, 30, 1)
                                JSpinner spinner = new JSpinner(sModel);
                                spinner.setBounds(0, 0, 40, 30);
                                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                                int option = JOptionPane.showOptionDialog(vista_solicitudes, spinner, "Cantidad en libras", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                int cantidad = (Integer) spinner.getValue();
                                if (option == JOptionPane.CANCEL_OPTION) {
                                    JOptionPane.showMessageDialog(vista_solicitudes, "Suministro no agregado");
                                } else if (option == JOptionPane.OK_OPTION) {
                                    try {
                                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                                        limpiar();
                                    } catch (Exception ex) {
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            }
                            case "990.SN100C": {
                                SpinnerNumberModel sModel = new SpinnerNumberModel(25, 25, 1000000, 25);//(0, 0, 30, 1)
                                JSpinner spinner = new JSpinner(sModel);
                                spinner.setBounds(0, 0, 40, 30);
                                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                                int option = JOptionPane.showOptionDialog(vista_solicitudes, spinner, "Cantidad en libras", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                int cantidad = (int) spinner.getValue();
                                if (option == JOptionPane.CANCEL_OPTION) {
                                    JOptionPane.showMessageDialog(vista_solicitudes, "Suministro no agregado");
                                } else if (option == JOptionPane.OK_OPTION) {
                                    try {
                                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                                        limpiar();
                                    } catch (Exception ex) {
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            }
                            case "890.1084": {
                                System.out.println("700 gramos c/u");
                                SpinnerNumberModel sModel = new SpinnerNumberModel(700, 700, 700000000, 700);//(0, 0, 30, 1)
                                JSpinner spinner = new JSpinner(sModel);
                                spinner.setBounds(0, 0, 40, 30);
                                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                                int option = JOptionPane.showOptionDialog(vista_solicitudes, spinner, "Cantidad en gramos", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                int cantidad = (int) spinner.getValue();
                                if (option == JOptionPane.CANCEL_OPTION) {
                                    JOptionPane.showMessageDialog(vista_solicitudes, "Suministro no agregado");
                                } else if (option == JOptionPane.OK_OPTION) {
                                    try {
                                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                                        limpiar();
                                    } catch (Exception ex) {
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            }
                            case "991.1024": {
                                System.out.println("Tubo");
                                SpinnerNumberModel sModel = new SpinnerNumberModel(1, 1, 1000000, 1);//(0, 0, 30, 1)
                                JSpinner spinner = new JSpinner(sModel);
                                spinner.setBounds(0, 0, 40, 30);
                                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                                int option = JOptionPane.showOptionDialog(vista_solicitudes, spinner, "Cantidad en tubos", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                int cantidad = (int) spinner.getValue();
                                if (option == JOptionPane.CANCEL_OPTION) {
                                    JOptionPane.showMessageDialog(vista_solicitudes, "Suministro no agregado");
                                } else if (option == JOptionPane.OK_OPTION) {
                                    try {
                                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                                        limpiar();
                                    } catch (Exception ex) {
                                        JOptionPane.showMessageDialog(vista_solicitudes, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            }
                        }
                    } else {

                        //
                        if (vista_solicitudes.getTxtNumParte().getText().equals(Aplicacion.dao.verificarNumParte(vista_solicitudes.getTxtNumParte().getText()))) {
                            if (visSolicitudes.getTxtNumParte().getText().equals("")) {
                                JOptionPane.showMessageDialog(null, "<html><h1>No ha indicado el número de parte</html></h1>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                            } else if (visSolicitudes.getTxtCantidad().getText().equals("")) {
                                JOptionPane.showMessageDialog(null, "<html><h1>Debe especificar una cantidad</html></h1>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                            } else if (!visSolicitudes.getTxtCantidad().getText().matches("[0-9]*")) {
                                JOptionPane.showMessageDialog(null, "<html><h1>Verifique la cantidad ingresada</html></h1>", "Información: Error de formato", JOptionPane.ERROR_MESSAGE);
                            } else {
                                agregarLista(vista_solicitudes.getTxtNumParte().getText(), Integer.valueOf(vista_solicitudes.getTxtCantidad().getText()));
                                limpiar();
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "<html><h2>El número de parte no existe en la base de datos</html></h2>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "<html><h1>Verifique la cantidad ingresada</html></h1>", "Información: Error de formato", JOptionPane.ERROR_MESSAGE);

                }

                break;
            }

            case "btnEliminarLista": {
                int index = -1;
                index = selectedRow;
                if (index < 0) {
                    JOptionPane.showMessageDialog(null, "<html><h2>No ha seleccionado nungún número de parte</html></h2>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    eliminarFila();
                }
                selectedRow = -1;
                break;
            }

            case "btnHacerSolicitud": {
                if (model.solicitudes == null) {
                    System.out.println("Error, null");
                } else {
                    if (vista_solicitudes.getTableSuministros().getRowCount() == 0) {
                        JOptionPane.showMessageDialog(null, "<html><h2>La lista está vacía</html></h2>", "Información: Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        hacerSolicitud();
                        model.solicitudes.removeAll(model.solicitudes);
                        selectedRow = -1;
                        model.notificarCambios();
                    }
                }
                break;
            }

            case "btnVerSolicitudes": {
                Aplicacion.crearVistaMisSolicitudes();
                break;
            }

            case "btnBucarCatalogo": {
                //Aplicacion.crearVistaCatalogo();
                Aplicacion.getCrearVistaCatalogo();
                break;
            }

            case "tableSuministros": {
                point = e.getPoint();
                selectedRow = vista_solicitudes.getTableSuministros().getSelectedRow();
                selectedColumns = vista_solicitudes.getTableSuministros().getSelectedColumn();
                break;
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e
    ) {
    }

    @Override
    public void mouseReleased(MouseEvent e
    ) {
    }

    @Override
    public void mouseEntered(MouseEvent e
    ) {
    }

    @Override
    public void mouseExited(MouseEvent e
    ) {
    }

    public void agregarLista(String numP, int cantidad) {
        try {
            model.agregarSolicitud(numP, cantidad);
        } catch (Exception e) {
            System.out.println("Error al agregar a lista : " + e.getMessage());
        }
    }

    /**
     * Method used to delete a supply from JTable
     */
    public void eliminarFila() {
        if (vista_solicitudes.getTableSuministros().getRowCount() == 0) {
            System.out.println("vacio");
        } else {
            model.solicitudes.remove(selectedRow);
            model.notificarCambios();
        }
    }

    /**
     * Method used to clear the view
     */
    private void limpiar() {
        visSolicitudes.getLblImagen().setIcon(dao.cargarImagenDefault());
        visSolicitudes.getTxtNumParte().setText("");
        visSolicitudes.getLblDescripcion().setText("");
        visSolicitudes.getLblNumeroParte().setText("");
        visSolicitudes.getLblUnidadMedida().setText("");
        visSolicitudes.getTxtCantidad().setText("");
        model.notificarCambios();
    }
}
