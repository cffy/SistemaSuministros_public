/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Vista.JFchooser;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import Vista.Vista_registroSuministro;
import Modelo.Modelo_registroSuministro;
import Aplicacion.Aplicacion;
import Entidades.Entidades_solicitud;
import Entidades.Entidades_usuario;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.sql.SQLException;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * Class control to Modelo_registroSuministro and Vista?registroSuministro
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_registroSuministro implements MouseListener, KeyListener {

    Modelo_registroSuministro modelo_registroSuministro;
    Vista_registroSuministro vista_registroSuministro;
    String numParteProcesar = "";
    File fichero;
    ImageIcon img;
    int lenImg;
    boolean flagActualizar;
    boolean flagEliminar;

    /**
     * Constructor of class
     *
     * @param modelo_registroSuministro instance of Modelo_registroSuministro
     * @param vista_registroSuministro instance of Vista_resgistroSuministro
     */
    public Control_registroSuministro(Modelo_registroSuministro modelo_registroSuministro, Vista_registroSuministro vista_registroSuministro) {
        this.modelo_registroSuministro = new Modelo_registroSuministro();
        this.vista_registroSuministro = vista_registroSuministro;
        this.vista_registroSuministro.setControl(this);
        this.vista_registroSuministro.setModelo_registroSuministro(modelo_registroSuministro);
    }

    /**
     * Method used to search a image to be saves in DB (saved in bits)
     */
    public void buscarImagen() {
        int resulado;
        JFchooser jf = new JFchooser();
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("JPG, PNG", "jpg", "png");
        jf.jfChooser.setFileFilter(filtro);
        resulado = jf.jfChooser.showOpenDialog(null);
        if (resulado == JFileChooser.APPROVE_OPTION) {
            try {
                fichero = jf.jfChooser.getSelectedFile();
                img = new ImageIcon(fichero.toString());
                Icon icono = new ImageIcon(img.getImage().getScaledInstance(vista_registroSuministro.getLblImagen().getWidth(),
                        vista_registroSuministro.getLblImagen().getHeight(), Image.SCALE_DEFAULT));
                vista_registroSuministro.getLblImagen().setIcon(icono);
            } catch (Exception e) {
            }
        }
    }

    /**
     * Method used to change the format of an image to bits
     */
    public FileInputStream convertirImagen() {
        String imgString = null;
        FileInputStream fis = null;
        try {
            imgString = img.toString();
            System.out.println("Datos de la imagen:\n"+imgString.length());
            File fileImg = new File(imgString);
            fis = new FileInputStream(fileImg);
            lenImg = (int) fileImg.length();
            System.out.println("Datos de lenImg:\n"+lenImg);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return fis;
    }

    /**
     * Method used to create a new supply in DB
     */
    public void crearRegistro() {
        String numP = vista_registroSuministro.getTxtNumparte().getText();
        String numP2 = Aplicacion.dao.verificarNumParte(numP);
        if (numP == numP2) {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>El número de parte ya existe</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        } else if (vista_registroSuministro.getTxtNumparte().getText().equals("")) {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Debe ingresar un número de parte</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        } else if (vista_registroSuministro.getTxtDescripcion().getText().equals("")) {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Debe ingresar una descripción</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        } else if (vista_registroSuministro.getTxtUnidadMedida().getText().equals("")) {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Debe ingresar una unidad de medida</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                convertirImagen();
                Aplicacion.dao.guardarNuevoSuministro(vista_registroSuministro.getTxtNumparte().getText(),
                        vista_registroSuministro.getTxtDescripcion().getText(),
                        vista_registroSuministro.getTxtUnidadMedida().getText(),
                        convertirImagen(), lenImg);
                limpiar();
            } catch (Exception e) {
                System.out.println("Error al crear el registro. Error> " + e.getMessage());
            }
        }
    }

    /**
     * method used to clean the view
     */
    public void limpiar() {
        vista_registroSuministro.getTxtNumparte().setText("");
        vista_registroSuministro.getTxtDescripcion().setText("");
        vista_registroSuministro.getTxtUnidadMedida().setText("");
        vista_registroSuministro.getLblImagen().setIcon(null);
        vista_registroSuministro.getBtnActualizar().setEnabled(false);
        vista_registroSuministro.getBtnEliminar().setEnabled(false);
        flagActualizar = false;
        flagEliminar = false;
        numParteProcesar = "";
    }

    /**
     * Method used to update a part number in DB
     */
    public void actializar() throws SQLException {
        if (validarUsuario() == true) {
            int confirmar = JOptionPane.showConfirmDialog(null, "<html><h1>¿Está seguro?</html></h1>", "Advertencia!", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirmar == JOptionPane.YES_OPTION) {
                Aplicacion.dao.actualizarSuministro(numParteProcesar,
                        vista_registroSuministro.getTxtDescripcion().getText(),
                        vista_registroSuministro.getTxtUnidadMedida().getText(),
                        convertirImagen(),
                        lenImg);
                JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Se ha actualizado el número de parte</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>No se han realizado cambios</html></h1>", "Información:", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Verifique sus credenciales</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * method used to search a specific supply
     */
    public void buscar() {
        numParteProcesar = vista_registroSuministro.getTxtNumparte().getText();
        if (validarUsuario() == true) {
            try {
                List<Entidades_solicitud> lista = Aplicacion.dao.buscar(vista_registroSuministro.getTxtNumparte().getText());
                if (lista.isEmpty()) {
                    JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>No se ha encontrado el numero de parte</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                    limpiar();
                } else {
                    vista_registroSuministro.getTxtNumparte().setText(lista.get(0).getNumParte());
                    vista_registroSuministro.getTxtDescripcion().setText(lista.get(0).getDescripcion());
                    vista_registroSuministro.getTxtUnidadMedida().setText(lista.get(0).getUnidadMedida());
                    vista_registroSuministro.getLblImagen().setIcon(lista.get(0).getImagen());
                    vista_registroSuministro.getBtnActualizar().setEnabled(true);
                    vista_registroSuministro.getBtnEliminar().setEnabled(true);
                    flagActualizar = true;
                    flagEliminar = true;
                }
            } catch (Exception e) {
            }
        } else {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Verifique sus credenciales</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Method used to validate a user
     */
    public boolean validarUsuario() {
        boolean log = false;
        JTextField userIN = new JTextField();
        JPasswordField passwordIN = new JPasswordField();
        Object[] loginInput = {"<html><h3>Usuario administrador</html></h3>", userIN, "<html><h3>Contraseña</html></h3>", passwordIN};
        int option = JOptionPane.showConfirmDialog(vista_registroSuministro, loginInput, "Credenciales", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        String userJO = userIN.getText();
        String passJP = passwordIN.getText();
        try {
            List<Entidades_usuario> loginEncontrados = Aplicacion.dao.login(userJO, passJP);
            if (loginEncontrados.isEmpty()) {
                log = false;
            } else {
                log = true;
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return log;
    }

    /**
     * Method used to delete a supply from DB
     */
    public void eliminarSuministro() {
        if (validarUsuario() == true) {
            int confirmar = JOptionPane.showConfirmDialog(vista_registroSuministro, "<html><h1>¿Está seguro?</html></h1>", "Advertencia!", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirmar == JOptionPane.YES_OPTION) {
                Aplicacion.dao.eliminarSuministro(numParteProcesar);
                JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Se ha eliminado el número de parte</html></h1>", "Información: Éxito!", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>No se han realizado cambios</html></h1>", "Información:", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>Verifique sus credenciales</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        switch (e.getComponent().getName()) {

            case "btnSeleccionarImg": {
                buscarImagen();
                break;
            }
            case "btnguardar": {
                crearRegistro();
                break;
            }
            case "btnBuscar": {
                if (!vista_registroSuministro.getTxtNumparte().equals("")) {
                    buscar();
                } else {
                    JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>No ha idicado el número de parte</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;
            }

            case "btnActualizar": {
                if (flagActualizar == true) {
                    try {
                        JOptionPane.showMessageDialog(vista_registroSuministro,
                                "<html><h3>Actualizar: considere lo siguiente:</html></h3>\n"
                                + "el sistema considera que se harán cambios en \n"
                                + "todos los campos a excepción del número de parte,\n"
                                + "es necesario volver a seleccionar la imagen, de lo\n"
                                + "contrario el sistema podría cargar una imagen default.", "Información:", JOptionPane.WARNING_MESSAGE);
                        actializar();
                        limpiar();
                    } catch (SQLException ex) {
                        System.out.println("error actualizar");
                    }
                }

                break;
            }
            case "btnEliminar": {
                if (flagEliminar == true) {
                    eliminarSuministro();
                    limpiar();
                }
                break;
            }
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getComponent().getName()) {
            case "txtNumparte": {
                if (e.getKeyCode() == e.VK_ENTER) {
                    if (!vista_registroSuministro.getTxtNumparte().equals("")) {
                        buscar();
                    } else {
                        JOptionPane.showMessageDialog(vista_registroSuministro, "<html><h1>No ha idicado el número de parte</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

}
