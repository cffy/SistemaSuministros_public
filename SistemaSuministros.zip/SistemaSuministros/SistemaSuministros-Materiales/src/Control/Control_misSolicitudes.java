/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Aplicacion.Aplicacion;
import Entidades.Entidades_solicitud;
import Modelo.Modelo_misSolicitudes;
import Modelo.Modelo_table_materiales;
import Vista.Vista_misSolicitudes;
import static java.awt.Frame.ICONIFIED;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Class constructor to Modelo_misSolicitudes and Vista_misSolicitudes
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_misSolicitudes implements MouseListener {

    public String statusSolicitud = "";
    public String statusMateriales = "";
    public String numParte = "";
    public int idSolicitud = 0;
    public int selectedRow = 0;
    public int selectedColumns = 0;
    Modelo_misSolicitudes modelo;
    Vista_misSolicitudes vista;
    Modelo_table_materiales modelo_table;
    Point point = new Point();

    /**
     * Constructor of class
     *
     * @param modelo instance of Modelo_misSolicitudes
     * @param vista instance of Vista_misSolicitudes
     * @param modelo_table instance of Modelo_table_solicitudes
     */
    public Control_misSolicitudes(Modelo_misSolicitudes modelo, Vista_misSolicitudes vista, Modelo_table_materiales modelo_table) {
        this.vista = vista;
        this.modelo = new Modelo_misSolicitudes();
        this.vista.setControl(this);
        this.vista.setModelo(modelo);
        this.vista.getTableMisSolicitudes().setModel(modelo.getTableModel());
    }

    /**
     * Method used to load the JTable with the user requests (by user)
     */
    public void cargarTablaMisSolicitudes() {
        try {
            List<Entidades_solicitud> solicitud = Aplicacion.dao.obtenerSolicitudesXusuario(Aplicacion.vista_solicitudes.getLblUser().getText());
            if (solicitud.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "<html><h1>No se han encontrado registro de solicitudes</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            }
            modelo.setTable(solicitud);
            modelo.notificarCambios();
        } catch (Exception ex) {
            System.out.println("Error cargarTablaMateriales> " + ex);
        }
        String qty = Integer.toString(vista.getTableMisSolicitudes().getRowCount());
        vista.getLblCantidadSolicitudes().setText(qty);
        vista.getTableMisSolicitudes().getColumnModel().getColumn(5).setPreferredWidth(90);
        vista.getTableMisSolicitudes().getColumnModel().getColumn(7).setPreferredWidth(35);
    }

    /**
     * Method used to change the request status
     */
    public void procesarStatus() {

        switch (statusMateriales) {
            case "Pendiente": {
                //JOptionPane.showMessageDialog(vista, "<html><center><h1>Esta solicitud no ha sido despachada por materiales</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);

                if (vista.getComboEstatus().getSelectedIndex() == 2) {
                    validarEstaus();
                    cargarTablaMisSolicitudes();
                    vista.getComboEstatus().setSelectedIndex(0);
                    numParte = "";
                    idSolicitud = 0;
                    statusMateriales = "";
                    statusSolicitud = "";
                } else if (vista.getComboEstatus().getSelectedIndex() == 1) {
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>Esta solicitud no ha sido despachada</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;

            }
            case "En proceso": {

                if (vista.getComboEstatus().getSelectedIndex() == 2) {
                    validarEstaus();
                    cargarTablaMisSolicitudes();
                    vista.getComboEstatus().setSelectedIndex(0);
                    numParte = "";
                    idSolicitud = 0;
                    statusMateriales = "";
                    statusSolicitud = "";
                } else if (vista.getComboEstatus().getSelectedIndex() == 1) {
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>Esta solicitud esta siendo preparada.</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;
            }

            case "Procesado": {
                if (vista.getComboEstatus().getSelectedIndex() != 2 && vista.getComboEstatus().getSelectedIndex() != 0) {

                    validarEstaus();
                    cargarTablaMisSolicitudes();
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>Suministro procesado.</html></center></h1>", "Información: Error!", JOptionPane.INFORMATION_MESSAGE);
                    vista.getComboEstatus().setSelectedIndex(0);
                    numParte = "";
                    idSolicitud = 0;
                    statusMateriales = "";
                    statusSolicitud = "";

                } else {
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>El suministro ya fue procesado, no se puede cancelar.</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;
            }
            case "Entregado": {
                if (vista.getComboEstatus().getSelectedIndex() != 2 && vista.getComboEstatus().getSelectedIndex() != 0) {
                    validarEstaus();
                    cargarTablaMisSolicitudes();
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>Suministro procesado.</html></center></h1>", "Información: Error!", JOptionPane.INFORMATION_MESSAGE);
                    vista.getComboEstatus().setSelectedIndex(0);
                    numParte = "";
                    idSolicitud = 0;
                    statusMateriales = "";
                    statusSolicitud = "";
                }
                else {
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>El suministro ya fue entregado, no se puede cancelar.</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;
            }

            case "No disponible": {//vista.getComboEstatus().getSelectedIndex() != 2 && 
                if (vista.getComboEstatus().getSelectedIndex() != 0 && vista.getComboEstatus().getSelectedIndex() != 1) {
                    validarEstaus();
                    cargarTablaMisSolicitudes();
                    JOptionPane.showMessageDialog(vista, "<html><center><h1>Suministro cancelado</html></center></h1>", "Información: Error!", JOptionPane.INFORMATION_MESSAGE);
                    vista.getComboEstatus().setSelectedIndex(0);
                    numParte = "";
                    idSolicitud = 0;
                    statusMateriales = "";
                    statusSolicitud = "";
                }
                break;
            }
        }

        /*if (statusMateriales.equals("Pendiente") || statusMateriales.equals("En proceso")) {
            JOptionPane.showMessageDialog(vista, "<html><center><h1>Esta solicitud no ha sido despachada por materiales</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);

        } else if (statusMateriales.equals("No disponible")) {
            JOptionPane.showMessageDialog(vista, "<html><center><h1>Suministro no disponible en bodega</html></center></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
        } else {
            if (statusSolicitud.equals("Recibido")) {
                JOptionPane.showMessageDialog(vista, "<html><h1>Esta solicitud ya ha sido recibida</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else if (statusSolicitud.equals("Cancelado")) {
                JOptionPane.showMessageDialog(vista, "<html><h1>Esta solicitud fue descartada</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else {
                if (numParte.equals("")) {
                    JOptionPane.showMessageDialog(vista, "<html><h1>Seleccione un número de parte y el estatus</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                } else {
                    validarEstaus();
                    cargarTablaMisSolicitudes();
                }
            }
            if (vista.getTableMisSolicitudes().getValueAt(selectedRow, selectedColumns).equals("Recibido")) {

            }
            vista.getComboEstatus().setSelectedIndex(0);
            numParte = "";
            idSolicitud = 0;
            statusMateriales = "";
            statusSolicitud = "";
        }
         */
    }

    /**
     * Method used to pass a local status per request and update in DB
     */
    public void validarEstaus() {
        String localEstatus = vista.getComboEstatus().getSelectedItem().toString();
        Aplicacion.dao.actiualizarSolicitud(numParte, idSolicitud, localEstatus);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        switch (e.getComponent().getName()) {

            case "tableMisSolicitudes": {
                point = e.getPoint();
                selectedRow = Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getSelectedRow();
                selectedColumns = Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getSelectedColumn();
                vista.getComboEstatus().setSelectedIndex(0);
                numParte = (String) Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getValueAt(selectedRow, 0);
                statusSolicitud = (String) Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getValueAt(selectedRow, 4);
                statusMateriales = (String) Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getValueAt(selectedRow, 5);
                idSolicitud = (int) Aplicacion.vista_misSolicitudes.getTableMisSolicitudes().getValueAt(selectedRow, 7);
                break;
            }

            case "btnCerrar": {
                vista.hide();
                break;
            }

            case "btnMinimizar": {
                vista.setExtendedState(ICONIFIED);
                break;
            }

            case "btnProcesar": {
                try {
                    procesarStatus();
                } catch (Exception ex) {

                }

                break;
            }

            case "btnActualizar": {
                cargarTablaMisSolicitudes();
                break;
            }

        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
