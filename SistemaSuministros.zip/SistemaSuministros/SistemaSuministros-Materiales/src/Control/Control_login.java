package Control;

import Entidades.Entidades_usuario;
import Modelo.Modelo_login;
import Vista.Vista_login;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import Aplicacion.Aplicacion;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Class control to Modelo_login and Vista_login
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_login implements MouseListener, KeyListener {

    Modelo_login modelo_login;
    Vista_login vista_login;

    /**
     * Constructor of class
     */
    public Control_login(Modelo_login modelo_login, Vista_login vista_login) {
        this.modelo_login = new Modelo_login();
        this.vista_login = vista_login;
        this.vista_login.setControl(this);
        this.vista_login.setModelo(modelo_login);
    }

    /**
     * Method used to validate if a user is registered in DB
     */
    public void login() {
        try {
            List<Entidades_usuario> loginList = Aplicacion.dao.login(vista_login.getTxtUser().getText(), vista_login.getTxtpassword().getText());
            if (loginList.isEmpty()) {
                JOptionPane.showMessageDialog(vista_login, "<html><h1>Verifique sus credenciales</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else {
                Aplicacion.crearVistaSolicitudes();
                Aplicacion.vista_solicitudes.getLblUser().setText(loginList.get(0).getNombre() + " " + loginList.get(0).getApellidos());
                vista_login.dispose();
            }
        } catch (Exception ex) {
            System.out.println("Error login> " + ex);
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {

        switch (e.getComponent().getName()) {
            case "btnCerrar": {
                System.exit(0);
                break;
            }
            case "btnEnter": {
                login();
                break;
            }
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        switch (e.getComponent().getName()) {
            case "txtpassword": {
                if (e.getKeyCode() == e.VK_ENTER) {
                    login();
                }
                break;
            }

        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

}
