
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Aplicacion.Aplicacion;
import Entidades.Entidades_solicitud;
import Modelo.Modelo_catalogo;
import Modelo.Modelo_table_catalogo;
import Vista.Vista_catalogo;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

/**
 * Class control to Modelo_catalogo and Vista_catalogo
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_catalogo implements MouseListener {

    private static Control_catalogo control_catalogo;

    private static Modelo_catalogo modelo_catalogo;
    private static Vista_catalogo vista_catalogo;
    private static Modelo_table_catalogo modelo_table_catalogo;
    String numParte;

    /**
     * Constructor of class
     */
    private Control_catalogo(Modelo_catalogo modelo_catalogo, Vista_catalogo vista_catalogo, Modelo_table_catalogo modelo_table_catalogo) {
        this.modelo_catalogo = new Modelo_catalogo();
        this.vista_catalogo = vista_catalogo;
        this.vista_catalogo.setControl(this);
        this.vista_catalogo.setModelo(modelo_catalogo);
        this.vista_catalogo.getTableCatalogo().setModel(modelo_catalogo.getTableModel());
        cargarTablaCatalogo();
    }

    public static Control_catalogo getCatalogo() {
        if (control_catalogo != null) {
            System.out.println("Catalogo existente");
            vista_catalogo.setVisible(true);
        } else {
            modelo_catalogo = new Modelo_catalogo();
            vista_catalogo = new Vista_catalogo();
            control_catalogo = new Control_catalogo(modelo_catalogo, vista_catalogo, modelo_table_catalogo);
            vista_catalogo.setVisible(true);
        }
        return control_catalogo;
    }

    /**
     * Method used to load the JTable with all the supplies
     */
    public void cargarTablaCatalogo() {
        try {
            List<Entidades_solicitud> catalogo = Aplicacion.dao.cargarCatalogo();
            if (catalogo.isEmpty()) {
                JOptionPane.showMessageDialog(vista_catalogo, "<html><h2>No se han registrado suministros</html></h2>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else {
                modelo_catalogo.setTable(catalogo);
                modelo_catalogo.notificarCambios();
            }
        } catch (Exception ex) {
            System.out.println("Error cargarTablaMateriales> " + ex);
        }
    }

    /**
     * Method used to add a new supply in the DB
     */
    public void agregar(String paramNumParte) {

        switch (paramNumParte) {
            case "990.1050": {
                SpinnerNumberModel sModel = new SpinnerNumberModel(25, 25, 1000000, 25);//(0, 0, 30, 1)
                JSpinner spinner = new JSpinner(sModel);
                spinner.setBounds(0, 0, 40, 30);
                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                int option = JOptionPane.showOptionDialog(vista_catalogo, spinner, "Cantidad en libras", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                int cantidad = (Integer) spinner.getValue();
                if (option == JOptionPane.CANCEL_OPTION) {
                    JOptionPane.showMessageDialog(vista_catalogo, "Suministro no agregado");
                } else if (option == JOptionPane.OK_OPTION) {
                    try {
                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }
            case "990.SN100C": {
                SpinnerNumberModel sModel = new SpinnerNumberModel(25, 25, 1000000, 25);//(0, 0, 30, 1)
                JSpinner spinner = new JSpinner(sModel);
                spinner.setBounds(0, 0, 40, 30);
                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                int option = JOptionPane.showOptionDialog(vista_catalogo, spinner, "Cantidad en libras", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                int cantidad = (int) spinner.getValue();
                if (option == JOptionPane.CANCEL_OPTION) {
                    JOptionPane.showMessageDialog(vista_catalogo, "Suministro no agregado");
                } else if (option == JOptionPane.OK_OPTION) {
                    try {
                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }
            case "890.1084": {
                System.out.println("700 gramos c/u");
                SpinnerNumberModel sModel = new SpinnerNumberModel(700, 700, 700000000, 700);//(0, 0, 30, 1)
                JSpinner spinner = new JSpinner(sModel);
                spinner.setBounds(0, 0, 40, 30);
                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                int option = JOptionPane.showOptionDialog(vista_catalogo, spinner, "Cantidad en gramos", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                int cantidad = (int) spinner.getValue();
                if (option == JOptionPane.CANCEL_OPTION) {
                    JOptionPane.showMessageDialog(vista_catalogo, "Suministro no agregado");
                } else if (option == JOptionPane.OK_OPTION) {
                    try {
                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }
            case "991.1024": {
                System.out.println("Tubo");
                SpinnerNumberModel sModel = new SpinnerNumberModel(1, 1, 1000000, 1);//(0, 0, 30, 1)
                JSpinner spinner = new JSpinner(sModel);
                spinner.setBounds(0, 0, 40, 30);
                ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
                int option = JOptionPane.showOptionDialog(vista_catalogo, spinner, "Cantidad en tubos", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                int cantidad = (int) spinner.getValue();
                if (option == JOptionPane.CANCEL_OPTION) {
                    JOptionPane.showMessageDialog(vista_catalogo, "Suministro no agregado");
                } else if (option == JOptionPane.OK_OPTION) {
                    try {
                        Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }
            default: {
                System.out.println("default");
                defCantidad(paramNumParte);
                break;
            }
        }
        numParte = "";
    }

    public int defCantidad(String paramNumParte) {
        int cantidad = 0;
        JTextField userIN = new JTextField();
        userIN.setBounds(2, 2, 40, 30);
        Object[] cantidades = {"<html><center><h3>Cantidad requerida</h3></center></html>", userIN};
        int opcion = JOptionPane.showConfirmDialog(vista_catalogo, cantidades, "Cantidad", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        try {
            cantidad = Integer.valueOf(userIN.getText());
            String cantidadTxt = userIN.getText();
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
            } else if (!cantidadTxt.matches("[0-9]*")) {
                JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
            } else if (cantidadTxt == null) {
                JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
            } else {
                Aplicacion.control_solicitudes.agregarLista(paramNumParte, cantidad);
                JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Agregado a la lista</html></h1>", "Información: Exito!", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista_catalogo, "<html><h1>Cantidad incorrecta</html></h1>", "Información: Error de formato!", JOptionPane.ERROR_MESSAGE);
        }
        return cantidad;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        switch (e.getComponent().getName()) {
            case "btnAgregar": {
                agregar(numParte);
                break;
            }
            case "tableCatalogo": {
                Point point = new Point();
                point = e.getPoint();
                int selectedRow = vista_catalogo.getTableCatalogo().getSelectedRow();
                int selectedColumns = vista_catalogo.getTableCatalogo().getSelectedColumn();
                numParte = (String) vista_catalogo.getTableCatalogo().getValueAt(selectedRow, 0);
                if (e.getClickCount() == 2) {
                    agregar(numParte);
                }
                break;
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
