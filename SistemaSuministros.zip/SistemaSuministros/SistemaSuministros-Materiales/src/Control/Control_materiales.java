/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Aplicacion.Aplicacion;
import Aplicacion.ExportarExcel;
import Entidades.Entidades_Login;
import Connector.DAO;
import Entidades.Entidades_solicitud;
import Entidades.Entidades_usuario;
import Modelo.Modelo_materiales;
import Modelo.Modelo_table_materiales;
import Vista.Vista_materiales;
import static java.awt.Frame.ICONIFIED;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Class control to Modelo_materiales and Vista_materiales
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Control_materiales implements MouseListener {

    Modelo_materiales model = new Modelo_materiales();
    Vista_materiales visMateriales;
    Entidades_solicitud entiSolicitudes;
    Entidades_Login entidades_Login;
    Aplicacion aplicacion;
    DAO dao;
    Modelo_table_materiales modelo_table;
    String numParte = "";
    String estatusMsteriales = "";
    String estatusSolicitud = "";
    int cantidad = 0;
    String solicitante = "";
    Date fecha = null;
    int iDSolicitud = 0;
    int selectedRow = 0;
    int selectedColumns = 0;
    int indexRegistrado = 0;
    int indexSeleccionado = 0;
    boolean btnEntregarStatus = false;
    Point point = new Point();
    String nombreValidacion;

    /**
     * Constructor of class
     */
    public Control_materiales(Modelo_materiales model, Vista_materiales visMateriales, Entidades_solicitud entiSolicitudes, Modelo_table_materiales modelo_table) {
        this.model = new Modelo_materiales();
        this.entiSolicitudes = new Entidades_solicitud();
        this.aplicacion = new Aplicacion();
        this.visMateriales = visMateriales;
        this.visMateriales.setControl(this);
        this.visMateriales.setModelo(model);
        this.visMateriales.getLblFecha().setText(model.fecha());
        this.visMateriales.getjTable1().setModel(model.getTableModel());
        this.entidades_Login = new Entidades_Login();
        this.nombreValidacion = "";
    }

    /**
     * Method used to load the JTable with the last 100 supplies request
     */
    public void cargarTablaMateriales100() {
        try {
            List<Entidades_solicitud> solicitud = Aplicacion.dao.obtenerSolicitudes100();
            if (solicitud.isEmpty()) {
                JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>No se han encontrado registro de solicitudes</HTML></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            }
            model.setTable(solicitud);
            model.notificarCambios();
            visMateriales.getButtonGroupVer().clearSelection();
        } catch (Exception ex) {
            System.out.println("Error cargarTablaMateriales> " + ex);
        }
    }

    public void cargarTablaMateriales() {
        try {
            List<Entidades_solicitud> solicitud = Aplicacion.dao.obtenerSolicitudes();
            if (solicitud.isEmpty()) {
                JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>No se han encontrado registro de solicitudes</HTML></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            }
            model.setTable(solicitud);
            model.notificarCambios();
        } catch (Exception ex) {
            System.out.println("Error cargarTablaMateriales> " + ex);
        }
    }

    /**
     * Method used to verify if a part number exist in DB, is a flag
     */
    public boolean validarSolicitud() {
        boolean flag = false;
        if (numParte.equals("")) {
            flag = false;
        } else {
            flag = true;
        }
        return flag;
    }

    /**
     * Method used to process a supply
     */
    public void tramitarSolicitud() {

        if (estatusMsteriales.equals("Entregado") /*|| estatusMsteriales.equals("Procesado")*/) {
            JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>Esta solicitud ya ha sido tramitada.</HTML></h1>", "Información:", JOptionPane.INFORMATION_MESSAGE);
            visMateriales.getComboEstatus().setSelectedIndex(0);
            visMateriales.getBtnEntragar().setEnabled(false);
            visMateriales.getComboEstatus().setEnabled(false);
            limpiar();

        } else if (estatusMsteriales.equals("No disponible")) {
            JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>No se puede procesar, debe ser solicitado nuevamente.</HTML></h1>", "Información:", JOptionPane.INFORMATION_MESSAGE);
            visMateriales.getComboEstatus().setSelectedIndex(0);
            visMateriales.getBtnEntragar().setEnabled(false);
            visMateriales.getComboEstatus().setEnabled(false);
            limpiar();
        } else if (estatusSolicitud.equals("Cancelado")) {
            JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>No se puede procesar, esta solicitud fue cancelada.</HTML></h1>", "Información:", JOptionPane.INFORMATION_MESSAGE);
            visMateriales.getComboEstatus().setSelectedIndex(0);
            visMateriales.getBtnEntragar().setEnabled(false);
            visMateriales.getComboEstatus().setEnabled(false);
            limpiar();
        } else {
            Aplicacion.vista_materiales.getLblNumParte().setText(numParte);
            Aplicacion.vista_materiales.getLblCantidad().setText(Integer.toString(cantidad));
            Aplicacion.vista_materiales.getLblSolicitante().setText(solicitante);
            Aplicacion.vista_materiales.getLblFechaSolicitud().setText(fecha.toString());

            switch (estatusMsteriales) {
                case "Pendiente": {
                    Aplicacion.vista_materiales.getComboEstatus().setSelectedIndex(0);
                    break;
                }
                case "En proceso": {
                    Aplicacion.vista_materiales.getComboEstatus().setSelectedIndex(1);
                    break;
                }
                case "Procesado": {
                    Aplicacion.vista_materiales.getComboEstatus().setSelectedIndex(2);
                    break;
                }
                case "No disponible": {
                    Aplicacion.vista_materiales.getComboEstatus().setSelectedIndex(3);
                    break;
                }

            }
            Aplicacion.vista_materiales.getComboEstatus().setEnabled(true);
            btnEntregarStatus = true;
            visMateriales.getBtnEntragar().setEnabled(true);
        }
    }

    /**
     * Method used to authenticate a user
     */
    public boolean validarEntrega() {
        boolean log = false;
        JTextField userIN = new JTextField();
        JPasswordField passwordIN = new JPasswordField();
        Object[] loginInput = {"<html><h3>Usuario</html></h3>", userIN, "<html><h3>Contraseña</html></h3>", passwordIN};
        int option = JOptionPane.showConfirmDialog(visMateriales, loginInput, "Credenciales", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        String userJO = userIN.getText();
        String passJP = passwordIN.getText();
        try {
            List<Entidades_usuario> loginEncontrados = Aplicacion.dao.login(userJO, passJP);
            if (loginEncontrados.isEmpty()) {
                log = false;
            } else {
                log = true;
                nombreValidacion = loginEncontrados.get(0).getNombre() + " " + loginEncontrados.get(0).getApellidos();
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return log;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        switch (e.getComponent().getName()) {

            case "btnCerrar": {
                System.exit(0);
                break;
            }

            case "btnMinimizar": {
                visMateriales.setExtendedState(ICONIFIED);
                break;
            }

            case "btnProcesar": {
                if (validarSolicitud() == true) {
                    tramitarSolicitud();
                } else {
                    JOptionPane.showMessageDialog(visMateriales, "<HTML><h1>No se puede procesar sin un numero de parte</HTML></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                }
                break;
            }

            case "jTable1": {
                point = e.getPoint();
                selectedRow = Aplicacion.vista_materiales.getjTable1().getSelectedRow();
                selectedColumns = Aplicacion.vista_materiales.getjTable1().getSelectedColumn();
                numParte = (String) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 0);
                cantidad = (int) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 1);
                solicitante = (String) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 2);
                fecha = (Date) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 3);
                estatusMsteriales = (String) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 5);
                estatusSolicitud = (String) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 4);
                iDSolicitud = (int) Aplicacion.vista_materiales.getjTable1().getValueAt(selectedRow, 7);

                switch (estatusMsteriales) {
                    case "Pendiente": {
                        indexRegistrado = 0;
                        break;
                    }
                    case "En proceso": {
                        indexRegistrado = 1;
                        break;
                    }
                    case "Procesado": {
                        indexRegistrado = 2;
                        break;
                    }
                    case "Entregado": {
                        indexRegistrado = 3;
                        break;
                    }
                    case "No disponible": {
                        indexRegistrado = 4;
                        break;
                    }
                }
                if (e.getClickCount() == 2) {
                    tramitarSolicitud();
                }
                break;
            }

            case "btnActualizar": {
                cargarTablaMateriales100();
                System.out.println("Actualizado");
                visMateriales.getButtonGroupVer().clearSelection();

                model.notificarCambios();
                break;
            }

            case "btnNuevoSuministro": {
                validarAccesoRegistros();
                break;
            }

            case "btnEntregar": {
                if (btnEntregarStatus == true && validarSolicitud() == true) {
                    if (validarEntrega() == true) {
                        if (visMateriales.getComboEstatus().getSelectedItem().toString().equals("Seleccione")) {
                            Aplicacion.dao.entregarMateriales(numParte, iDSolicitud, "Pendiente", "No asignado");
                        } else {
                            if (visMateriales.getComboEstatus().getSelectedIndex() < indexRegistrado) {
                                JOptionPane.showMessageDialog(visMateriales, "<html><h1>No puede cambiar el estatus a un estatus anterior.</h1></html>", "Error!", JOptionPane.ERROR_MESSAGE);
                                System.out.println("Index: " + indexSeleccionado);
                            } else {
                                Aplicacion.dao.entregarMateriales(numParte, iDSolicitud, visMateriales.getComboEstatus().getSelectedItem().toString(), nombreValidacion);
                                cargarTablaMateriales100();
                                model.notificarCambios();
                                JOptionPane.showMessageDialog(visMateriales, "Suministro procesado", "Exito!", JOptionPane.INFORMATION_MESSAGE);
                                visMateriales.getBtnEntragar().setEnabled(false);
                                numParte = "";
                                visMateriales.getComboEstatus().setEnabled(false);
                                visMateriales.getComboEstatus().setSelectedIndex(0);
                                indexSeleccionado = 0;
                                indexRegistrado = 0;
                                limpiar();

                                System.out.println("Index: " + indexSeleccionado);
                            }

                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "<html><h1>Credenciales incorrectas</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            }

            case "radioVer100": {
                cargarTablaMateriales100();

                break;
            }

            case "radioVerTodo": {

                cargarTablaMateriales();
                break;
            }

            case "btnReporteExcel": {
                ExportarExcel exportar = new ExportarExcel();
                try {
                    exportar.exportarExcel(visMateriales.getjTable1());
                } catch (IOException ex) {
                    Logger.getLogger(Control_materiales.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }

    }

    public boolean xmlReader(String nombre) {
        boolean flag = false;
        try {
            File inputFile = new File("accessDataForeingPassValidation.dat");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("userTipo");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                Element eElement = null;
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    eElement = (Element) nNode;
                    System.out.println("User type: " + eElement.getAttribute("id"));
                    System.out.println("User Type : " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
                    if (nombre.equals(eElement.getElementsByTagName("nombre").item(0).getTextContent())) {
                        System.out.println("El usuario encontrado: " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
                        System.out.println("El usuario existe");
                        flag = true;
                        break;
                    } else {
                        System.out.println("No es =( ");
                        flag = false;
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return flag;
    }

    public void validarAccesoRegistros() {
        JTextField userIN = new JTextField();
        JPasswordField passwordIN = new JPasswordField();
        Object[] loginInput = {"<html><h3>Usuario</html></h3>", userIN, "<html><h3>Contraseña</html></h3>", passwordIN};
        int option = JOptionPane.showConfirmDialog(visMateriales, loginInput, "Credenciales", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        String userJO = userIN.getText();
        String passJP = passwordIN.getText();
        try {
            List<Entidades_usuario> loginEncontrados = Aplicacion.dao.login(userJO, passJP);
            if (loginEncontrados.isEmpty()) {
                JOptionPane.showMessageDialog(visMateriales, "<html><h1>Credenciales incorrectas</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);
            } else if (xmlReader(loginEncontrados.get(0).getNombre()) == true) {
                Aplicacion.crearVistaRegistroSuministro();
            } else {
                JOptionPane.showMessageDialog(visMateriales, "<html><h1>Credenciales incorrectas o sin permiso</html></h1>", "Información: Error!", JOptionPane.ERROR_MESSAGE);

            }
        } catch (Exception ex) {

        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Method used to clean the view
     */
    private void limpiar() {
        visMateriales.getLblNumParte().setText("");
        visMateriales.getLblCantidad().setText("");
        visMateriales.getLblFechaSolicitud().setText("");
        visMateriales.getLblSolicitante().setText("");
        nombreValidacion = "";
        visMateriales.getButtonGroupVer().clearSelection();
    }

}
