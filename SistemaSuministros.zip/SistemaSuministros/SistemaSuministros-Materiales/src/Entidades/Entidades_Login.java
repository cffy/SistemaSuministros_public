/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 * Class to handle the login data
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Entidades_Login {

    public String usuario;
    public String password;
    public String nombre;
    public String apellidos;

    /**
     * Constructor of class
     */
    public Entidades_Login() {
        this.usuario = "";
        this.password = "";
        this.nombre = "";
        this.apellidos = "";
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

}
