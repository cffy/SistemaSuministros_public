/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * Class to handle the information of a request
 *
 * @author Freddy Cascante Fernandez
 * @version 09/08/2019/V1.0
 */
public class Entidades_solicitud {

    String idSolicitante;
    String nombreDespachador;
    String numParte;
    String nota;
    String descripcion;
    String user;
    String estadoSolicitud;
    String estadoMateriales;
    String unidadMedida;
    String cantidad;
    Date fechaSolicitud;
    int idSolicitud;
    int qty;
    boolean flagEntregado;
    boolean flagRecibido;
    ImageIcon imagen;
    JLabel imgLabel;

    /**
     * Constructor of class
     */
    public Entidades_solicitud() {
        this.idSolicitante = "";
        this.nombreDespachador = "";
        this.numParte = "";
        this.nota = "";
        this.user = "";
        this.cantidad = "";
        this.estadoMateriales = "";
        this.estadoSolicitud = "";
        this.unidadMedida = "";
        this.fechaSolicitud = null;
        this.idSolicitud = 0;
        this.qty = 0;
        this.flagEntregado = false;
        this.flagRecibido = false;
        this.imagen = new ImageIcon();
        this.imgLabel = new JLabel();
    }

    public String getIdSolicitante() {
        return idSolicitante;
    }

    public ImageIcon getImagen() {
        return imagen;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public void setImagen(ImageIcon imagen) {
        this.imagen = imagen;
    }

    public void setIdSolicitante(String idSolicitante) {
        this.idSolicitante = idSolicitante;
    }

    public JLabel getImgLabel() {
        return imgLabel;
    }

    public void setImgLabel(JLabel imgLabel) {
        this.imgLabel = imgLabel;
    }

    public String getEstadoSolicitud() {
        return estadoSolicitud;
    }

    public void setEstadoSolicitud(String estadoSolicitud) {
        this.estadoSolicitud = estadoSolicitud;
    }

    public String getEstadoMateriales() {
        return estadoMateriales;
    }

    public void setEstadoMateriales(String estadoMateriales) {
        this.estadoMateriales = estadoMateriales;
    }

    public String getNombreDespachador() {
        return nombreDespachador;
    }

    public void setNombreDespachador(String nombreDespachador) {
        this.nombreDespachador = nombreDespachador;
    }

    public String getNumParte() {
        return numParte;
    }

    public void setNumParte(String numParte) {
        this.numParte = numParte;
    }

    public String getNota() {
        return nota;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public int getIdSolicitud() {
        return idSolicitud;
    }

    public void setIdSolicitud(int idSolicitud) {
        this.idSolicitud = idSolicitud;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public boolean isFlagEntregado() {
        return flagEntregado;
    }

    public void setFlagEntregado(boolean flagEntregado) {
        this.flagEntregado = flagEntregado;
    }

    public boolean isFlagRecibido() {
        return flagRecibido;
    }

    public void setFlagRecibido(boolean flagRecibido) {
        this.flagRecibido = flagRecibido;
    }

}
