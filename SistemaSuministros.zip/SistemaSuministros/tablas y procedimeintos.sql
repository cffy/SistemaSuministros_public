/*
Tablas y procedimientos
*/

CREATE TABLE [dbo].[Suministros_TablaRegistro](
	[NumParte] [nvarchar](50) NOT NULL,
	[Descripcion] [varchar](150) NULL,
	[UnidadMedida] [varchar](50) NULL,
	[Imagen] [image] NULL,
	[Cantidad] [int] NULL,
 CONSTRAINT [PK_Suministros_TablaRegistro] PRIMARY KEY CLUSTERED 
(
	[NumParte] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


CREATE TABLE [dbo].[Suministros_TableSolicitudes](
	[NumParte] [nvarchar](50) NOT NULL,
	[Cantidad] [nvarchar](50) NOT NULL,
	[Usuario] [nvarchar](50) NOT NULL,
	[Fecha] [datetime] NOT NULL,
	[Estatus] [nvarchar](50) NOT NULL,
	[EstatusMateriales] [nvarchar](50) NOT NULL,
	[NombreDespachador] [nvarchar](100) NOT NULL,
	[IdSolicitud] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Suministros_HistoricoCantidad](
	[IdCantidad] [int] IDENTITY(1,1) NOT NULL,
	[NumParte] [varchar](50) NOT NULL,
	[CantidadAnterior] [int] NOT NULL,
	[CantidadInventario] [int] NOT NULL,
	[UltimaSolicitud] [int] NOT NULL,
	[CantidadTotal] [int] NOT NULL,
	[Fecha] [date] NOT NULL
) ON [PRIMARY]
GO





